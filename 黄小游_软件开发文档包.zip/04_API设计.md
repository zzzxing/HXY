# 黄小游研学智能体 API 设计

## 1. 设计原则

1. REST 风格优先
2. 命名直观
3. 尽量围绕业务对象组织
4. 适合 Next.js Route Handlers 实现

---

## 2. 认证

使用 Supabase Auth。  
前端登录后通过 session / token 访问接口。

---

## 3. API 列表

## 3.1 认证与用户

### GET `/api/me`
获取当前登录用户信息。

**返回**
```json
{
  "id": "uuid",
  "name": "张三",
  "role": "student"
}
```

---

## 3.2 活动管理

### GET `/api/activities`
根据当前角色返回活动列表。

### POST `/api/activities`
创建活动。

**请求体**
```json
{
  "title": "黄石工业文化研学",
  "description": "围绕工业文化开展研学活动",
  "theme": "工业文化",
  "target_grade": "七年级",
  "start_date": "2026-05-10",
  "end_date": "2026-05-10"
}
```

### GET `/api/activities/:id`
获取活动详情。

### PATCH `/api/activities/:id`
更新活动。

### POST `/api/activities/:id/publish`
发布活动。

### POST `/api/activities/:id/finish`
结束活动。

---

## 3.3 活动班级关联

### POST `/api/activities/:id/classes`
给活动绑定班级。

**请求体**
```json
{
  "class_ids": ["uuid1", "uuid2"]
}
```

---

## 3.4 点位管理

### GET `/api/activities/:id/sites`
获取活动点位列表。

### POST `/api/activities/:id/sites`
新增点位。

**请求体**
```json
{
  "name": "矿博物馆展厅A",
  "order_index": 1,
  "intro": "矿石标本展示区",
  "knowledge_text": "这里展示了多种矿石样本……",
  "key_facts": "重点观察颜色、纹理、用途",
  "problem_chain": [
    {"level":"核心问题","content":"这里最值得观察的现象是什么？"}
  ],
  "evidence_checklist": [
    "拍摄两种矿石照片",
    "记录它们的外观差异"
  ]
}
```

### GET `/api/sites/:siteId`
获取单个点位详情。

### PATCH `/api/sites/:siteId`
更新点位。

### DELETE `/api/sites/:siteId`
删除点位。

### POST `/api/sites/:siteId/qrcode`
生成点位二维码。

---

## 3.5 任务管理

### GET `/api/activities/:id/tasks`
获取活动任务列表。

### POST `/api/activities/:id/tasks`
新增任务。

**请求体**
```json
{
  "phase": "learn",
  "title": "导学问题准备",
  "description": "围绕研学主题提出3个问题",
  "task_type": "text",
  "sort_order": 1,
  "required": true
}
```

### PATCH `/api/tasks/:taskId`
更新任务。

### DELETE `/api/tasks/:taskId`
删除任务。

---

## 3.6 学生问题清单

### GET `/api/activities/:id/questions`
获取当前学生的问题清单。

### POST `/api/activities/:id/questions`
新增问题。

**请求体**
```json
{
  "phase": "learn",
  "content": "黄石工业为什么重要？",
  "category": "basic",
  "site_id": null
}
```

### DELETE `/api/questions/:questionId`
删除问题。

---

## 3.7 AI 问答

### POST `/api/ai/chat`
学生向 AI 提问。

**请求体**
```json
{
  "activity_id": "uuid",
  "site_id": "uuid-or-null",
  "phase": "visit",
  "message": "这个矿石和旁边那个有什么不同？"
}
```

**返回**
```json
{
  "reply": "你可以先从颜色、表面纹理和用途三个角度观察它们的不同。先告诉我你看到的两个明显差异。"
}
```

---

## 3.8 证据上传

### POST `/api/uploads/sign`
获取上传签名或上传配置。

### POST `/api/evidences`
保存证据记录。

**请求体**
```json
{
  "activity_id": "uuid",
  "student_id": "uuid",
  "site_id": "uuid",
  "task_id": "uuid",
  "evidence_type": "image",
  "file_url": "https://...",
  "text_content": "",
  "note": "这是我拍摄的矿石照片"
}
```

### GET `/api/activities/:id/evidences`
获取当前学生或教师可见的证据列表。

---

## 3.9 学习档案

### POST `/api/activities/:id/portfolio/generate`
为当前学生生成学习档案。

### GET `/api/activities/:id/portfolio`
获取当前学生学习档案。

### GET `/api/activities/:id/portfolios`
教师查看班级档案列表。

### PATCH `/api/portfolios/:portfolioId/review`
教师评价档案。

**请求体**
```json
{
  "teacher_score": 92,
  "teacher_comment": "能够围绕问题开展观察，证据记录较完整。"
}
```

---

## 3.10 后台资源管理

### GET `/api/admin/schools`
### POST `/api/admin/schools`

### GET `/api/admin/classes`
### POST `/api/admin/classes`

### GET `/api/admin/users`
### POST `/api/admin/users`

---

## 4. 返回格式约定

### 成功
```json
{
  "success": true,
  "data": {}
}
```

### 失败
```json
{
  "success": false,
  "message": "权限不足"
}
```

---

## 5. 错误处理约定

- 400：参数错误
- 401：未登录
- 403：无权限
- 404：资源不存在
- 500：服务器错误

---

## 6. 接口开发优先级

### 第一批必须完成
- `/api/me`
- `/api/activities`
- `/api/activities/:id`
- `/api/activities/:id/sites`
- `/api/activities/:id/tasks`
- `/api/ai/chat`
- `/api/evidences`
- `/api/activities/:id/portfolio`

### 第二批
- 导出接口
- 管理员接口
- 统计接口

---

## 7. 说明

如果 Codex 一次性难以全部完成，可以按页面倒推接口：
1. 先做活动列表与详情
2. 再做点位页
3. 再做上传
4. 再做 AI
5. 再做档案
